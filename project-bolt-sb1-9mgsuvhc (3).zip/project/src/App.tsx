import React from 'react';
import { Github, Linkedin, Mail, ExternalLink, Code2, Database, Globe, Server, 
         Home, GraduationCap, FolderGit2, Users, Wrench, Menu, X } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Menu Button */}
      <button 
        onClick={() => setIsMenuOpen(!isMenuOpen)}
        className="fixed top-4 right-4 z-50 p-2 bg-gray-900 text-white rounded-lg md:hidden hover-scale"
      >
        {isMenuOpen ? <X size={24} className="transition-transform duration-300 rotate-90" /> : 
                     <Menu size={24} className="transition-transform duration-300 hover:rotate-180" />}
      </button>

      {/* Side Navigation */}
      <nav className={`fixed top-0 left-0 h-full w-64 bg-gray-900 text-white z-40 transform transition-all duration-500 ease-in-out ${
        isMenuOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full md:translate-x-0'
      }`}>
        <div className="h-full flex flex-col py-8">
          <div className="px-6 mb-8 animate-fade-in">
            <h2 className="text-xl font-bold">Harshit Gupta</h2>
            <p className="text-sm text-gray-400">Software Engineer</p>
          </div>
          
          <div className="flex-1 px-4 stagger-animation">
            {[
              { id: 'home', icon: <Home size={20} />, label: 'Home' },
              { id: 'about', icon: <Users size={20} />, label: 'About' },
              { id: 'education', icon: <GraduationCap size={20} />, label: 'Education' },
              { id: 'tools', icon: <Wrench size={20} />, label: 'Tools' },
              { id: 'projects', icon: <FolderGit2 size={20} />, label: 'Projects' },
              { id: 'contact', icon: <Mail size={20} />, label: 'Contact' }
            ].map((item) => (
              <button 
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-gray-800 rounded-lg mb-2 transition-all duration-300 hover:pl-6 animate-slide-in menu-item"
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            ))}
          </div>

          <div className="px-6 pt-4 border-t border-gray-800">
            <div className="flex justify-center space-x-4 stagger-animation">
              {[
                { icon: <Github size={20} />, href: '#' },
                { icon: <Linkedin size={20} />, href: '#' },
                { icon: <Mail size={20} />, href: '#' }
              ].map((social, index) => (
                <a 
                  key={index}
                  href={social.href} 
                  className="p-2 hover:text-blue-400 transition-all duration-300 hover-scale animate-slide-in"
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="md:ml-64">
        {/* Hero Section */}
        <header id="home" className="relative h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 to-gray-800 text-white overflow-hidden">
          <div className="absolute inset-0 opacity-20 transition-transform duration-1000 hover:scale-110" style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&q=80')",
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}></div>
          <div className="relative z-10 text-center px-4 animate-fade-in">
            <h1 className="text-5xl md:text-7xl font-bold mb-4">Harshit Gupta</h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-8">Software Engineer & Full Stack Developer</p>
          </div>
        </header>

        {/* About Section */}
        <section id="about" className="py-20 px-4 md:px-8">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center">About Me</h2>
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="rounded-lg overflow-hidden hover-scale">
                <img 
                  src="https://drive.google.com/file/d/1dKQB0cLXvT470gKrnJlTVOee8jAcFDO3/view?usp=sharingauto=format&fit=crop&q=80" 
                  alt="Profile"
                  className="w-full h-[400px] object-cover transition-transform duration-700 hover:scale-110"
                />
              </div>
              <div>
                <p className="text-lg text-gray-600 mb-6">
                  I'm a passionate software engineer with expertise in building scalable web applications
                  and distributed systems. With 2+ years of experience in full-stack development,
                  I specialize in creating robust and efficient solutions using modern technologies.
                </p>
                <div className="flex flex-wrap gap-3 stagger-animation">
                  {['C/C++','Java','HTML/CSS','Javascript','PHP','React', 'Node.js', 'TypeScript', 'Python', 'AWS','AI/ML'].map((skill, index) => (
                    <span key={index} className="px-4 py-2 bg-gray-100 rounded-full text-sm hover-scale animate-slide-in">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Education Section */}
        <section id="education" className="py-20 px-4 md:px-8 bg-gray-100">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Education</h2>
            <div className="space-y-8 stagger-animation">
              {[
                {
                  degree: 'Bachelor of Technogy (Computer Science)',
                  school: 'Graphic Era University',
                  years: '2021 - 2025'
                }
              ].map((edu, index) => (
                <div key={index} className="bg-white p-6 rounded-lg shadow-md hover-scale animate-slide-in">
                  <div className="flex items-center gap-4 mb-4">
                    <GraduationCap className="w-8 h-8 text-blue-500" />
                    <div>
                      <h3 className="text-xl font-semibold">{edu.degree}</h3>
                      <p className="text-gray-600">{edu.school}</p>
                    </div>
                  </div>
                  <p className="text-gray-600">{edu.years}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Tools Section */}
        <section id="tools" className="py-20 px-4 md:px-8">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Tools & Technologies</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 stagger-animation">
              {[
                {
                  icon: <Code2 className="w-12 h-12 text-blue-500 mb-4" />,
                  title: 'Languages',
                  skills: 'C/C++, Python, JavaScript, TypeScript, Java, Html, Css, Php'
                },
                {
                  icon: <Server className="w-12 h-12 text-green-500 mb-4" />,
                  title: 'Backend',
                  skills: 'Node.js, Django, Spring Boot,'
                },
                {
                  icon: <Globe className="w-12 h-12 text-purple-500 mb-4" />,
                  title: 'Frontend',
                  skills: 'React, Vue.js, Next.js'
                },
                {
                  icon: <Database className="w-12 h-12 text-orange-500 mb-4" />,
                  title: 'Databases',
                  skills: 'PostgreSQL, MongoDB, Redis'
                }
              ].map((tool, index) => (
                <div key={index} className="flex flex-col items-center p-6 bg-white rounded-lg shadow-md hover-scale animate-fade-in">
                  {tool.icon}
                  <h3 className="text-lg font-semibold">{tool.title}</h3>
                  <p className="text-gray-600 text-center mt-2">{tool.skills}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section id="projects" className="py-20 px-4 md:px-8 bg-gray-100">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Featured Projects</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 stagger-animation">
              {[1,].map((project) => (
                <div key={project} className="bg-white rounded-lg overflow-hidden shadow-lg transition-all duration-300 hover:-translate-y-2 hover:shadow-xl animate-fade-in">
                  <div className="overflow-hidden">
                    <img 
                      src={`https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80`}
                      alt={`Project ${project}`}
                      className="w-full h-48 object-cover transition-transform duration-700 hover:scale-110"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2">Modern Webtoon & Video Streaming Platform Design {project}</h3>
                    <p className="text-gray-600 mb-4">
                      This project focused on creating a user-centric, interactive platform for webtoon reading and video streaming with enhanced Human-Computer Interaction (HCI). The design emphasizes seamless user experience (UX), accessibility, performance, and aesthetic appeal. Key features include:
Webtoon Reading: Infinite scroll, panel-by-panel view, customizable reading modes (day/night, brightness, font size), bookmarking, interactive comments, and offline reading.
Video Streaming: High-quality adaptive streaming, interactive subtitles, synchronized watch parties, playback speed control, and offline downloads.
User Interface (UI): Minimalistic design with dark mode default, customizable themes, and smooth animations. Advanced search, filters, and persistent navigation enhance usability.
Community Features: User profiles, community forums, creator interaction, and fan art galleries.
Monetization: Subscription plans, microtransactions, ad-supported model, and merchandise store.
 </p>
                    <div className="flex justify-between items-center">
                      <div className="flex space-x-2">
                        <span className="px-2 py-1 bg-gray-100 rounded text-sm hover-scale">React</span>
                        <span className="px-2 py-1 bg-gray-100 rounded text-sm hover-scale">Node.js</span>
                        <span className="px-2 py-1 bg-gray-100 rounded text-sm hover-scale">Vue.js</span>
                      </div>
                      <a href="webtoonflix.netlify.app" className="text-blue-500 hover:text-blue-600 transition-transform duration-300 hover:scale-110">
                        <ExternalLink size={20} />
                      </a>
                    </div>
                  </div>
                </div>
              ))}

              {[2,].map((project) => (
                <div key={project} className="bg-white rounded-lg overflow-hidden shadow-lg transition-all duration-300 hover:-translate-y-2 hover:shadow-xl animate-fade-in">
                  <div className="overflow-hidden">
                    <img 
                      src={`https://www.rd.com/wp-content/uploads/2023/09/These-Simple-Online-Travel-Tools-Helped-Me-Save-911-on-My-Vacation_Getty-Images_1384947546_1157761892_Social.jpg?fit=680%2C454?auto=format&fit=crop&q=80`}
                      alt={`Project ${project}`}
                      className="w-full h-48 object-cover transition-transform duration-700 hover:scale-110"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2">Travel Experience Marketplace(AI + Customization) Website {project}</h3>
                    <p className="text-gray-600 mb-4">
                      Built a AI-Powered Personalization: Utilize AI to analyze user inputs such as travel preferences (e.g., adventure vs. relaxation, urban vs. rural, budget, etc.) and past travel experiences. The AI can also recommend destinations, accommodations, tours, activities, and dining options based on this data.
Local Guide Integration: Partner with local guides who can offer personalized tours and experiences, giving travelers the ability to explore destinations from a local's perspective. Use AI to match users with the best-rated or most suitable guides.
Dynamic Itinerary Builder: Allow users to create and modify their itineraries easily. The system can automatically adjust suggestions based on their chosen destinations, budget, dates, and interests. Users can also get live updates on availability and local events during their stay.
Real-Time Availability & Booking: Integration with booking systems for flights, hotels, and activities (tours, events, etc.) directly on the platform. Users can instantly confirm bookings in one streamlined process.
 </p>
                    <div className="flex justify-between items-center">
                      <div className="flex space-x-2">
                        <span className="px-2 py-1 bg-gray-100 rounded text-sm hover-scale">React</span>
                        <span className="px-2 py-1 bg-gray-100 rounded text-sm hover-scale">Node.js</span>
                        <span className="px-2 py-1 bg-gray-100 rounded text-sm hover-scale">Python</span>
                        <span className="px-2 py-1 bg-gray-100 rounded text-sm hover-scale"></span>
                      </div>
                      <a href="#" className="text-blue-500 hover:text-blue-600 transition-transform duration-300 hover:scale-110">
                        <ExternalLink size={20} />
                      </a>
                    </div>
                  </div>
                </div>
              ))}

              {[3,].map((project) => (
                <div key={project} className="bg-white rounded-lg overflow-hidden shadow-lg transition-all duration-300 hover:-translate-y-2 hover:shadow-xl animate-fade-in">
                  <div className="overflow-hidden">
                    <img 
                      src={`https://cdn.prod.website-files.com/64f1cb4a73596e4aeb543ab2/65afe1358577f74a7c2475ad_cover.jpg?auto=format&fit=crop&q=80`}
                      alt={`Project ${project}`}
                      className="w-full h-48 object-cover transition-transform duration-700 hover:scale-110"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2">Smart Task Management System with AI Integration {project}</h3>
                    <p className="text-gray-600 mb-4">
                      This project is a Smart Task Management System that uses Artificial Intelligence to help users manage their tasks, prioritize activities, and optimize their workflow. The system offers both basic task management features (creating, editing, and deleting tasks) along with advanced AI functionalities like task prioritization, deadline prediction, and productivity analysis based on user behavior.

The AI component analyzes past user interactions, suggests the best time to complete tasks based on historical productivity trends, and offers productivity tips to improve time management. The goal is to create a seamless user experience that not only keeps tasks organized but actively assists users in managing their time more effectively.

 </p>
                    <div className="flex justify-between items-center">
                      <div className="flex space-x-2">
                        <span className="px-2 py-1 bg-gray-100 rounded text-sm hover-scale">HTML/CSS</span>
                        <span className="px-2 py-1 bg-gray-100 rounded text-sm hover-scale">Node.js</span>
                        <span className="px-2 py-1 bg-gray-100 rounded text-sm hover-scale">Python</span>
                        <span className="px-2 py-1 bg-gray-100 rounded text-sm hover-scale">TensorFlow</span>
                        <span className="px-2 py-1 bg-gray-100 rounded text-sm hover-scale">Api integration</span>
                      </div>
                      <a href="#" className="text-blue-500 hover:text-blue-600 transition-transform duration-300 hover:scale-110">
                        <ExternalLink size={20} />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20 px-4 md:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-8">Get In Touch</h2>
            <p className="text-lg text-gray-600 mb-8">
              I'm always open to discussing new projects, creative ideas, or opportunities to be part of your visions.
            </p>
            <a 
              href="mailto:guptaharshit279@gmail.com"
              className="inline-flex items-center gap-2 bg-blue-500 text-white px-6 py-3 rounded-lg transition-all duration-300 hover:bg-blue-600 hover:-translate-y-1 hover:shadow-lg"
            >
              <Mail size={20} />
              Send Message
            </a>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-8 bg-gray-900 text-gray-400 text-center">
          <p>© {new Date().getFullYear()} Harshit Gupta. All rights reserved.</p>
        </footer>
      </main>
    </div>
  );
}

export default App;